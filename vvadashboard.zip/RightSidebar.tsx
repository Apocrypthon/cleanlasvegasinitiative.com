import React, { useState, useEffect } from 'react';
import { User } from './types.ts';

interface RightSidebarProps {
  isOpen: boolean;
  onClose: () => void;
  currentUser: User | null;
  onLogin: (user: User) => void;
  onLogout: () => void;
}

function RightSidebar({ isOpen, onClose, currentUser, onLogin, onLogout }: RightSidebarProps) {
  const [email, setEmail] = useState('');
  const [error, setError] = useState('');

  useEffect(() => {
    // Clear form when sidebar opens/closes or user changes
    if (isOpen && !currentUser) {
      setEmail('');
      setError('');
    }
  }, [isOpen, currentUser]);

  const handleLoginFormSubmit = (event: React.FormEvent) => {
    event.preventDefault();
    if (!email.trim()) {
      setError('Email cannot be empty.');
      return;
    }
    if (!email.includes('@')) {
        setError('Please enter a valid email address.');
        return;
    }

    let role: 'manager' | 'auditor' = 'auditor';
    if (email.toLowerCase().endsWith('@vegasvistaacademy.org')) {
      role = 'manager';
    }
    
    onLogin({ email: email.trim(), role });
    // setError(''); // Clear error on successful login attempt
    // setEmail(''); // Clear email on successful login attempt
    // onClose(); // Managed by App.tsx handleLogin
  };

  return (
    <div className={`right-sidebar ${isOpen ? 'open' : ''}`} role="complementary" aria-hidden={!isOpen}>
      <div className="right-sidebar-header">
        <h2>{currentUser ? 'User Profile' : 'Login'}</h2>
        <button onClick={onClose} className="close-btn" aria-label="Close sidebar">
          &times;
        </button>
      </div>

      {currentUser ? (
        <div className="user-details">
          <p><strong>Email:</strong> {currentUser.email}</p>
          <p><strong>Role:</strong> {currentUser.role.charAt(0).toUpperCase() + currentUser.role.slice(1)}</p>
          <button onClick={() => {
            onLogout();
            // onClose(); // App.tsx handleLogout manages opening the sidebar again
          }}>Logout</button>
        </div>
      ) : (
        <form onSubmit={handleLoginFormSubmit} noValidate>
          <div className="form-group">
            <label htmlFor="sidebar-email">Email Address:</label>
            <input
              type="email"
              id="sidebar-email"
              value={email}
              onChange={(e) => {
                setEmail(e.target.value);
                if (error) setError(''); // Clear error when user types
              }}
              placeholder="user@example.com"
              required
              aria-describedby={error ? "sidebar-email-error" : undefined}
              aria-invalid={!!error}
            />
          </div>
          {error && <p id="sidebar-email-error" className="error-message" role="alert">{error}</p>}
          <button type="submit">Login</button>
        </form>
      )}
    </div>
  );
}

export default RightSidebar;
