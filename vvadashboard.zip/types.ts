export interface User {
  email: string;
  role: 'manager' | 'auditor';
}

export interface Asset {
  id: string; // Internal unique ID
  itemName: string;
  modelNumber: string;
  assetId: string; // Official asset tag ID
  serialNumber: string;
  acquired: 'In Stock' | 'Assigned' | 'In Repair' | 'Disposed'; // Simplified status for 'acquired' field
  issueCondition: string;
  assignedTo?: string; // User, department, or team
  acquisitionDate: string; // YYYY-MM-DD
  dateOfDisposal?: string; // YYYY-MM-DD
  percentFederalParticipation: number; // e.g., 0.5 for 50%
  costOfProperty: number;
  salePrice?: number;
  locationRoomNumber: string; // e.g., "M101"
  status: 'operational' | 'needs_repair' | 'disposed' | 'in_storage' | 'out_for_repair';
  lastServicedDate?: string; // YYYY-MM-DD
}

export interface HistoryEntry {
  id: string;
  timestamp: string; // ISO 8601 format
  assetId: string; // Relates to Asset.id or Asset.assetId
  user: string; // Email of user or "System"
  action: string; // e.g., "Created", "Edited (Field: Status)", "Assigned", "Marked as Serviced", "Deleted"
  details: string; // More specific details of the change
}

export interface Room {
  id: string; // e.g., "M101"
  name: string; // e.g., "Classroom M101"
  type: 'classroom' | 'restroom' | 'utility' | 'corridor' | 'exit' | 'office' | 'storage';
  // Optional explicit coordinates and dimensions for more precise SVG rendering
  x?: number;
  y?: number;
  width?: number;
  height?: number;
}

export interface FloorPlan {
  buildingId: string; // e.g., "BLDG M"
  buildingName: string;
  address?: string;
  rooms: Room[];
}
