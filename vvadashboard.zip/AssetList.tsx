import React from 'react';
import { Asset, User } from './types.ts';

interface AssetListProps {
  assets: Asset[];
  user: User | null; // User can be null before login
  onEditAsset: (asset: Asset) => void;
  onDeleteAsset: (assetId: string) => void;
}

function AssetList({ assets, user, onEditAsset, onDeleteAsset }: AssetListProps) {
  if (!user) {
    return <div className="asset-list-container no-assets"><p>Please log in to view assets.</p></div>;
  }
  
  if (assets.length === 0) {
    return <div className="asset-list-container no-assets"><p>No assets found matching your criteria.</p></div>;
  }

  return (
    <div className="asset-list-container">
      <h3>Asset Records</h3>
      <table className="asset-table" aria-live="polite">
        <thead>
          <tr>
            <th>Item Name</th>
            <th>Asset ID</th>
            <th>Model No.</th>
            <th>Location</th>
            <th>Status</th>
            <th>Issue/Condition</th>
            {user && user.role === 'manager' && <th>Actions</th>}
          </tr>
        </thead>
        <tbody>
          {assets.map((asset) => (
            <tr key={asset.id}>
              <td>{asset.itemName}</td>
              <td>{asset.assetId}</td>
              <td>{asset.modelNumber}</td>
              <td>{asset.locationRoomNumber}</td>
              <td>{asset.status}</td>
              <td>{asset.issueCondition}</td>
              {user && user.role === 'manager' && (
                <td className="actions">
                  <button 
                    onClick={() => onEditAsset(asset)} 
                    className="edit-btn"
                    aria-label={`Edit asset ${asset.itemName}`}
                  >
                    Edit
                  </button>
                  <button 
                    onClick={() => onDeleteAsset(asset.id)} 
                    className="delete-btn"
                    aria-label={`Delete asset ${asset.itemName}`}
                  >
                    Delete
                  </button>
                </td>
              )}
            </tr>
          ))}
        </tbody>
      </table>
    </div>
  );
}

export default AssetList;
