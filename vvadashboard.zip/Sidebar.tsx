import React from 'react';
import { User } from './types.ts';

interface SidebarProps {
  user: User | null; // User can be null before login
  onSearch: (searchTerm: string) => void;
  onAddAssetClick: () => void;
}

function Sidebar({ user, onSearch, onAddAssetClick }: SidebarProps) {
  return (
    <aside className="sidebar">
      <h2>Navigation</h2>
      <div className="search-bar">
        <input
          type="search"
          placeholder="Search assets (name, ID)..."
          onChange={(e) => onSearch(e.target.value)}
          aria-label="Search assets by name or ID"
          disabled={!user} // Disable search if not logged in
        />
      </div>

      {user && user.role === 'manager' && (
        <button 
          className="add-asset-btn" 
          onClick={onAddAssetClick}
          aria-label="Add new asset"
        >
          Add New Asset
        </button>
      )}
      
      {!user && (
        <p style={{ marginTop: '20px', color: '#6c757d', textAlign: 'center' }}>
          Please log in to manage assets.
        </p>
      )}
      {/* Future: History Log Link */}
      {/* {user && (
          <div style={{marginTop: 'auto', paddingTop: '20px', borderTop: '1px solid #ccc'}}>
            <p>History logs (Auditor/Manager)</p>
          </div>
        )} 
      */}
    </aside>
  );
}

export default Sidebar;
