import React, { useState, useEffect, useCallback } from 'react';
import Dashboard from './Dashboard.tsx';
import RightSidebar from './RightSidebar.tsx';
import { User, Asset, HistoryEntry } from './types.ts';
import { MOCK_ASSETS, MOCK_HISTORY } from './mockData.ts';

function App() {
  const [currentUser, setCurrentUser] = useState<User | null>(null);
  const [assets, setAssets] = useState<Asset[]>(MOCK_ASSETS);
  const [history, setHistory] = useState<HistoryEntry[]>(MOCK_HISTORY);
  const [lastUpdated, setLastUpdated] = useState<string>(new Date().toLocaleTimeString());
  const [isRightSidebarOpen, setIsRightSidebarOpen] = useState<boolean>(false);

  useEffect(() => {
    // Open sidebar by default if not logged in
    if (!currentUser) {
      setIsRightSidebarOpen(true);
    } else {
      setIsRightSidebarOpen(false); // Close if user gets set (e.g. from a persisted session in future)
    }
  }, [currentUser]);

  // Simulate SSE for timestamp update
  useEffect(() => {
    const intervalId = setInterval(() => {
      setLastUpdated(new Date().toLocaleTimeString());
    }, 30000); // Update every 30 seconds
    return () => clearInterval(intervalId);
  }, []);

  const handleLogin = useCallback((user: User) => {
    setCurrentUser(user);
    setIsRightSidebarOpen(false); // Close sidebar on successful login
  }, []);

  const handleLogout = useCallback(() => {
    setCurrentUser(null);
    setIsRightSidebarOpen(true); // Open sidebar to show login form again
  }, []);

  const toggleRightSidebar = useCallback(() => {
    setIsRightSidebarOpen(prev => !prev);
  }, []);

  const handleCreateAsset = useCallback((newAsset: Omit<Asset, 'id'>) => {
    const generatedId = `ASSET-${Date.now()}`;
    const fullNewAsset = { ...newAsset, id: generatedId } as Asset; // Ensure all fields are there or default
    setAssets(prevAssets => [
      ...prevAssets,
      fullNewAsset
    ]);
    setHistory(prevHistory => [...prevHistory, {
      id: `HIST-${Date.now()}`,
      timestamp: new Date().toISOString(),
      assetId: generatedId,
      user: currentUser?.email || 'System',
      action: 'Created Asset',
      details: `Asset ${newAsset.itemName} created.`
    }]);
  }, [currentUser]);

  const handleUpdateAsset = useCallback((updatedAsset: Asset) => {
    setAssets(prevAssets =>
      prevAssets.map(asset => (asset.id === updatedAsset.id ? updatedAsset : asset))
    );
     setHistory(prevHistory => [...prevHistory, {
      id: `HIST-${Date.now()}`,
      timestamp: new Date().toISOString(),
      assetId: updatedAsset.id,
      user: currentUser?.email || 'System',
      action: 'Updated Asset',
      details: `Asset ${updatedAsset.itemName} (ID: ${updatedAsset.assetId}) updated.`
    }]);
  }, [currentUser]);

  const handleDeleteAsset = useCallback((assetIdToDelete: string) => {
    const assetName = assets.find(a => a.id === assetIdToDelete)?.itemName || 'Unknown';
    setAssets(prevAssets => prevAssets.filter(asset => asset.id !== assetIdToDelete));
    setHistory(prevHistory => [...prevHistory, {
      id: `HIST-${Date.now()}`,
      timestamp: new Date().toISOString(),
      assetId: assetIdToDelete,
      user: currentUser?.email || 'System',
      action: 'Deleted Asset',
      details: `Asset ${assetName} (ID: ${assetIdToDelete}) deleted.`
    }]);
  }, [assets, currentUser]);

  return (
    <>
      <Dashboard
        user={currentUser}
        assets={assets}
        // history={history} // Not yet used in Dashboard UI
        onCreateAsset={handleCreateAsset}
        onUpdateAsset={handleUpdateAsset}
        onDeleteAsset={handleDeleteAsset}
        lastUpdated={lastUpdated}
        toggleRightSidebar={toggleRightSidebar}
      />
      <RightSidebar
        isOpen={isRightSidebarOpen}
        onClose={toggleRightSidebar}
        currentUser={currentUser}
        onLogin={handleLogin}
        onLogout={handleLogout}
      />
      {isRightSidebarOpen && <div className={`overlay ${isRightSidebarOpen ? 'active' : ''}`} onClick={toggleRightSidebar}></div>}
    </>
  );
}

export default App;
