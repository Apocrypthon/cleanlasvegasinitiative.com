import { FloorPlan } from './types.ts';

// Approximate dimensions and positions for a simple layout
const R_W = 80; // Room Width
const R_H = 60; // Room Height
const M = 10;   // Margin

export const BLDG_M_FLOOR_PLAN: FloorPlan = {
  buildingId: 'BLDG M',
  buildingName: 'Main Office Building',
  address: '4656 N. Rancho Dr.',
  rooms: [
    // North Row (East to West)
    { id: 'M101', name: 'Office M101', type: 'office', x: M, y: M, width: R_W, height: R_H },
    { id: 'UtilityBlock', name: 'Utility Block (Elec, Roof, Fire)', type: 'utility', x: M + R_W + M, y: M, width: R_W, height: R_H },
    { id: 'M102', name: 'Office M102', type: 'office', x: M + 2*(R_W + M), y: M, width: R_W, height: R_H },
    { id: 'M103', name: 'Office M103', type: 'office', x: M + 3*(R_W + M), y: M, width: R_W, height: R_H },
    { id: 'NorthRestroom', name: 'North Restroom', type: 'restroom', x: M + 4*(R_W + M), y: M, width: R_W, height: R_H },
    { id: 'M104', name: 'Office M104', type: 'office', x: M + 5*(R_W + M), y: M, width: R_W, height: R_H },
    
    // South Row (East to West) - roughly aligned under North Row
    { id: 'M108', name: 'Office M108', type: 'office', x: M, y: M + R_H + M, width: R_W, height: R_H },
    // No direct room under UtilityBlock in South Row as per simple plan, M107 is next to M108
    { id: 'M107', name: 'Office M107', type: 'office', x: M + 2*(R_W + M), y: M + R_H + M, width: R_W, height: R_H }, // Aligned under M102
    { id: 'M106', name: 'Office M106', type: 'office', x: M + 3*(R_W + M), y: M + R_H + M, width: R_W, height: R_H }, // Aligned under M103
    { id: 'SouthRestroom', name: 'South Restroom', type: 'restroom', x: M + 4*(R_W + M), y: M + R_H + M, width: R_W, height: R_H }, // Aligned under NorthRestroom
    { id: 'M105', name: 'Office M105', type: 'office', x: M + 5*(R_W + M), y: M + R_H + M, width: R_W, height: R_H }, // Aligned under M104

    // Central Corridor (could be represented implicitly or as a large room)
    // For simplicity, not explicitly drawn as a clickable room, but affects room placement.
    // The given coordinates try to make a somewhat coherent layout.

    // Utility 'AAA' is small, can be part of M103 or NorthRestroom block for this simplification
  ],
};
