import React, { useState, useEffect, useRef } from 'react';
import { FloorPlan, Room } from './types.ts';

interface MapDisplayProps {
  floorPlan: FloorPlan;
  onRoomSelect: (roomId: string | null) => void;
  selectedRoomId: string | null;
  assetsInRooms: Record<string, number>; // Count of assets per room
}

// Basic dimensions for rooms, assuming a grid-like layout for simplicity
const ROOM_WIDTH = 80;
const ROOM_HEIGHT = 60;
const ROOM_MARGIN = 10;
const TEXT_OFFSET_Y = ROOM_HEIGHT / 2 + 5; // Center text vertically
const MAX_SVG_WIDTH = 600; // Max width for the SVG container

function MapDisplay({ floorPlan, onRoomSelect, selectedRoomId, assetsInRooms }: MapDisplayProps) {
  const [scale, setScale] = useState(1);
  const svgRef = useRef<SVGSVGElement>(null);

  // Simplified layout logic: position rooms based on their order in the data
  // This is a very basic representation and would need more sophisticated logic for complex plans
  const getRoomPosition = (room: Room, index: number, totalRoomsRow: number) => {
    // Attempt a more structured layout based on the description
    // This is still highly simplified
    let x = ROOM_MARGIN, y = ROOM_MARGIN;
    const roomsPerRow = Math.ceil(Math.sqrt(floorPlan.rooms.length)); // rough estimate

    if (['M101', 'UtilityBlock', 'M102', 'M103', 'NorthRestroom', 'M104'].includes(room.id)) { // North row
        y = ROOM_MARGIN;
        if (room.id === 'M101') x = ROOM_MARGIN;
        else if (room.id === 'UtilityBlock') x = ROOM_MARGIN + (ROOM_WIDTH + ROOM_MARGIN);
        else if (room.id === 'M102') x = ROOM_MARGIN + 2 * (ROOM_WIDTH + ROOM_MARGIN);
        else if (room.id === 'M103') x = ROOM_MARGIN + 3 * (ROOM_WIDTH + ROOM_MARGIN);
        else if (room.id === 'NorthRestroom') x = ROOM_MARGIN + 4 * (ROOM_WIDTH + ROOM_MARGIN);
        else if (room.id === 'M104') x = ROOM_MARGIN + 5 * (ROOM_WIDTH + ROOM_MARGIN);
    } else { // South row (M108, M107, M106, M105, SouthRestroom) roughly aligned under north
        y = ROOM_MARGIN + ROOM_HEIGHT + ROOM_MARGIN;
         if (room.id === 'M108') x = ROOM_MARGIN; // Aligns under M101
         else if (room.id === 'M107') x = ROOM_MARGIN + 2 * (ROOM_WIDTH + ROOM_MARGIN); // Aligns under M102
         else if (room.id === 'M106') x = ROOM_MARGIN + 3 * (ROOM_WIDTH + ROOM_MARGIN); // Aligns under M103
         else if (room.id === 'M105') x = ROOM_MARGIN + 5 * (ROOM_WIDTH + ROOM_MARGIN) ; // Aligns under M104
         else if (room.id === 'SouthRestroom') x = ROOM_MARGIN + 4 * (ROOM_WIDTH + ROOM_MARGIN); // Roughly where it fits
    }
    
    // Override with explicit coords if available
    if (room.x !== undefined && room.y !== undefined) {
      return { x: room.x, y: room.y, width: room.width || ROOM_WIDTH, height: room.height || ROOM_HEIGHT };
    }

    return { x, y, width: ROOM_WIDTH, height: ROOM_HEIGHT };
  };

  const viewBoxWidth = MAX_SVG_WIDTH;
  // Calculate height based on number of rows (simplified)
  // This is a placeholder for dynamic calculation based on actual room positions
  const numRows = 2; // Approximate rows for BLDG M
  const viewBoxHeight = numRows * (ROOM_HEIGHT + ROOM_MARGIN) + ROOM_MARGIN;


  const handleZoomIn = () => setScale(s => Math.min(s * 1.2, 3));
  const handleZoomOut = () => setScale(s => Math.max(s / 1.2, 0.5));
  const handleResetZoom = () => setScale(1);

  return (
    <div className="map-container">
      <h3>{floorPlan.buildingName} ({floorPlan.buildingId}) Floor Plan</h3>
      <div className="map-controls">
        <button onClick={handleZoomIn} aria-label="Zoom in map">+</button>
        <button onClick={handleZoomOut} aria-label="Zoom out map">-</button>
        <button onClick={handleResetZoom} aria-label="Reset map zoom">Reset Zoom</button>
      </div>
      <svg
        ref={svgRef}
        className="map-svg"
        viewBox={`0 0 ${viewBoxWidth} ${viewBoxHeight}`}
        preserveAspectRatio="xMidYMid meet"
        style={{ transform: `scale(${scale})`, transformOrigin: 'top left' }}
        aria-labelledby="map-title"
        role="img"
      >
        <title id="map-title">{floorPlan.buildingName} Floor Plan</title>
        {floorPlan.rooms.map((room, index) => {
          const { x, y, width, height } = getRoomPosition(room, index, floorPlan.rooms.length / 2); // Crude row calc
          const isSelected = room.id === selectedRoomId;
          const assetCount = assetsInRooms[room.id] || 0;
          return (
            <g key={room.id} onClick={() => onRoomSelect(isSelected ? null : room.id)}
               aria-label={`Room ${room.name}. ${assetCount} assets. Status: ${isSelected ? 'Selected' : 'Not selected'}.`}
               role="button"
               tabIndex={0}
               onKeyDown={(e) => { if (e.key === 'Enter' || e.key === ' ') onRoomSelect(isSelected ? null : room.id); }}
            >
              <rect
                x={x}
                y={y}
                width={width}
                height={height}
                className={`room ${isSelected ? 'selected' : ''}`}
                aria-hidden="true"
              />
              <text x={x + width / 2} y={y + TEXT_OFFSET_Y - 5} className="room-text" aria-hidden="true">
                {room.id}
              </text>
              {assetCount > 0 && (
                <text x={x + width / 2} y={y + TEXT_OFFSET_Y + 10} className="room-text" style={{fontSize: '8px', fill: isSelected ? '#fff': '#333'}} aria-hidden="true">
                  ({assetCount} assets)
                </text>
              )}
            </g>
          );
        })}
      </svg>
    </div>
  );
}

export default MapDisplay;
