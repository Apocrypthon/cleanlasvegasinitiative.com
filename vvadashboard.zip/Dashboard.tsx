import React, { useState, useMemo } from 'react';
import Sidebar from './Sidebar.tsx';
import MapDisplay from './MapDisplay.tsx';
import AssetList from './AssetList.tsx';
import { User, Asset, HistoryEntry } from './types.ts';
import { BLDG_M_FLOOR_PLAN } from './floorPlanData.ts';

interface DashboardProps {
  user: User | null; // User can be null before login
  assets: Asset[];
  // history: HistoryEntry[]; // Not used in UI yet
  onCreateAsset: (newAsset: Omit<Asset, 'id'>) => void;
  onUpdateAsset: (updatedAsset: Asset) => void;
  onDeleteAsset: (assetId: string) => void;
  lastUpdated: string;
  toggleRightSidebar: () => void;
}

function Dashboard({
  user,
  assets,
  onCreateAsset,
  onUpdateAsset,
  onDeleteAsset,
  lastUpdated,
  toggleRightSidebar,
}: DashboardProps) {
  const [searchTerm, setSearchTerm] = useState('');
  const [selectedRoom, setSelectedRoom] = useState<string | null>(null);

  const handleSearch = (term: string) => {
    setSearchTerm(term.toLowerCase());
    setSelectedRoom(null); // Clear room selection when searching
  };

  const handleRoomSelect = (roomId: string | null) => {
    setSelectedRoom(roomId);
    setSearchTerm(''); // Clear search term when selecting a room
  };

  const filteredAssets = useMemo(() => {
    let currentAssets = assets;
    if (selectedRoom) {
      currentAssets = currentAssets.filter(
        (asset) => asset.locationRoomNumber === selectedRoom
      );
    }
    if (searchTerm) {
      currentAssets = currentAssets.filter(
        (asset) =>
          asset.itemName.toLowerCase().includes(searchTerm) ||
          (asset.assetId && asset.assetId.toLowerCase().includes(searchTerm)) ||
          (asset.serialNumber && asset.serialNumber.toLowerCase().includes(searchTerm))
      );
    }
    return currentAssets;
  }, [assets, searchTerm, selectedRoom]);
  
  const handleShowAllAssets = () => {
    setSelectedRoom(null);
    setSearchTerm('');
  };

  // If user is not logged in, Dashboard might show a loading state or limited view.
  // For now, it will render, but RightSidebar will overlay for login.
  // Or, you could return a "Please log in" message or redirect if !user here.
  // For this setup, we assume App.tsx handles the visibility logic via RightSidebar.

  return (
    <div className="app-container">
      <header className="app-header">
        <h1>Vegas Vista Academy - Maintenance</h1>
        <div className="header-controls">
          {user && (
            <div className="user-info">
              <span>{user.email} ({user.role})</span>
            </div>
          )}
          <button 
            className="hamburger-menu" 
            onClick={toggleRightSidebar}
            aria-label={user ? "Open user menu" : "Open login panel"}
            title={user ? "User Menu / Logout" : "Login"}
          >
            &#9776; {/* Hamburger Icon */}
          </button>
        </div>
      </header>

      {/* Render main content only if user is logged in, or show a login prompt area */}
      {/* For now, we allow main content to render and rely on sidebar overlay */}
      <main className="app-main">
        <Sidebar
          user={user} // Pass user, can be null
          onSearch={handleSearch}
          onAddAssetClick={() => {
            if (user?.role === 'manager') {
              alert('Add New Asset form placeholder. This will open a modal/form.');
            } else {
              alert('You do not have permission to add assets.');
            }
          }}
        />
        <div className="main-content">
          <div className="main-content-toolbar">
            <h2>Dashboard Overview</h2>
            {(selectedRoom || searchTerm) && (
                 <button onClick={handleShowAllAssets}>Show All Assets</button>
            )}
          </div>
          <MapDisplay
            floorPlan={BLDG_M_FLOOR_PLAN}
            onRoomSelect={handleRoomSelect}
            selectedRoomId={selectedRoom}
            assetsInRooms={assets.reduce((acc, asset) => {
              if (asset.locationRoomNumber) {
                acc[asset.locationRoomNumber] = (acc[asset.locationRoomNumber] || 0) + 1;
              }
              return acc;
            }, {} as Record<string, number>)}
          />
          <AssetList
            assets={filteredAssets}
            user={user} // Pass user, can be null
            onEditAsset={(asset) => {
              if (user?.role === 'manager') {
                alert(`Edit asset placeholder: ${asset.itemName}`);
              }
            }}
            onDeleteAsset={(assetId) => {
              if (user?.role === 'manager') {
                if(window.confirm('Are you sure you want to delete this asset?')) {
                  onDeleteAsset(assetId);
                }
              }
            }}
          />
           <div className="status-bar">
            Last updated: {lastUpdated}
          </div>
        </div>
      </main>
    </div>
  );
}

export default Dashboard;
